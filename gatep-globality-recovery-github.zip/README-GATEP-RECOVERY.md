# Run this in GitHub

Copy `.github/` and `scripts/` into the root of the same repository that ran the previous Gate-P workflow.

Then run: Actions -> Bubbleverse Gate P - GLOBALITY RECOVERY -> Run workflow.

Final artifact: `gatep-globality-recovery`.
Main files: `GATEP_GLOBALITY_RESULT.json`, `GATEP_GLOBALITY_REPORT.md`, `results/lcdm/best.json`, `results/1ax/best.json`, `results/2ax/best.json`, all seed YAML/log files, and provenance.

This workflow repairs globality only. Final Gate P still requires the separate theory-precision test |delta chi2_theory| <= 0.1.
