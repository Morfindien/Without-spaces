# Final Gate-P fit blockers

The validation workflow may be run now. The final physics fit must remain blocked until both items below are resolved.

## 1. Frozen base cosmology priors / parameterisation

The frozen HYP-004C record explicitly fixes the EDE priors, field count, potential and initial angles.

For an exact Gate-P comparison we must additionally recover the original construction setup for base cosmological parameters, including the geometry parameter used in the sampler (for example H0 vs theta_s / theta_MC), its prior, and all other base priors.

Do **not** silently substitute the ACT or SPT example cosmology priors.

Required deliverable before fit:
- `configs/frozen_base_params.yaml`
- provenance identifying the source file / analysis configuration it was recovered from.

## 2. Exact Cobaya → mAxiCLASS multi-field input mapping

The frozen mAxiCLASS Python wrapper stringifies parameter values before CLASS parses them. Multi-field values therefore need an explicitly tested serialization format.

We must verify, at the pinned mAxiCLASS commit, how these are passed for `N_mscf=2`:

- `n_axion_mscf`
- `log10_maxion_ac`
- `fraction_maxion_ac`
- `theta_ini_mscf`
- `theta_prime_ini_mscf`

Required deliverable before fit:
- one successful direct two-field CLASS smoke test,
- one successful two-field Cobaya/classy smoke test,
- exact serialization recorded in a config/helper module.

Only after both blockers are closed should `gatep_lcdm.yaml`, `gatep_1ax.yaml` and `gatep_2ax.yaml` be finalized.
