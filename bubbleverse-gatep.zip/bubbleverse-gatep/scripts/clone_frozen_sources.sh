#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EXT="${ROOT}/external"
mkdir -p "${EXT}"

clone_at_commit () {
  local url="$1"
  local dir="$2"
  local commit="$3"

  if [[ ! -d "${dir}/.git" ]]; then
    git clone --filter=blob:none "${url}" "${dir}"
  fi
  git -C "${dir}" fetch --depth 1 origin "${commit}"
  git -C "${dir}" checkout --detach "${commit}"
  test "$(git -C "${dir}" rev-parse HEAD)" = "${commit}"
}

clone_at_commit \
  https://github.com/marcobeIIa/mAxiCLASS.git \
  "${EXT}/mAxiCLASS" \
  b5a3af9818d04d2fe696e54972545e8c6805f4ea

clone_at_commit \
  https://github.com/ACTCollaboration/DR6-ACT-lite.git \
  "${EXT}/DR6-ACT-lite" \
  0e0cd2c703c62a0e980470b572602233b27750e1

clone_at_commit \
  https://github.com/SouthPoleTelescope/spt_candl_data.git \
  "${EXT}/spt_candl_data" \
  2cec6e762a8c540484dd5acafc529f0035856350

echo "Frozen sources checked out successfully."
