#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="${ROOT}/external/mAxiCLASS"
OUT="${ROOT}/results/validation"
mkdir -p "${OUT}"

cd "${SRC}"
make clean || true
PYTHON=python make -j2

python - <<'PY'
from classy import Class
c = Class()
print("mAxiCLASS classy import: OK")
print("Class object:", type(c).__name__)
PY

# Run the exact upstream one-field shooting example as a physics-level smoke test.
mkdir -p output
set +e
timeout 25m ./class 1shooting_maxiclass.ini > "${OUT}/maxiclass_1shooting.log" 2>&1
status=$?
set -e

if [[ $status -eq 124 ]]; then
  echo "mAxiCLASS smoke test timed out after 25 minutes."
  exit 124
elif [[ $status -ne 0 ]]; then
  echo "mAxiCLASS smoke test failed. See maxiclass_1shooting.log"
  exit "$status"
fi

echo "mAxiCLASS build + one-field shooting smoke test: OK"
