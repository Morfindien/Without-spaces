#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="${ROOT}/external/spt_candl_data"
OUT="${ROOT}/results/validation"
mkdir -p "${OUT}"

python -m pip install "candl-like==2.0.3"
python -m pip install -e "${SRC}"

python "${ROOT}/scripts/validate_spt.py" 2>&1 | tee "${OUT}/spt_tests.log"

echo "SPT D1/candl validation: OK"
