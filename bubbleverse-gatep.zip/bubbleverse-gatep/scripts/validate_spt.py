from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
out = root / "results" / "validation"
out.mkdir(parents=True, exist_ok=True)

import candl
import spt_candl_data

print("candl import:", candl.__file__)
print("spt_candl_data import:", spt_candl_data.__file__)
print("Running supplied SPT candl data tests...")
result = spt_candl_data.run_all_tests()
print("SPT run_all_tests() completed.")
print("Return value:", result)
