#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROV="${ROOT}/provenance"
mkdir -p "${PROV}"

{
  echo "timestamp_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "uname=$(uname -a)"
  echo "python=$(python --version 2>&1)"
  echo "pip=$(python -m pip --version)"
  echo "gcc=$(gcc --version | head -n 1)"
  echo "g++=$(g++ --version | head -n 1)"
  echo "mAxiCLASS=$(git -C "${ROOT}/external/mAxiCLASS" rev-parse HEAD)"
  echo "ACT_DR6=$(git -C "${ROOT}/external/DR6-ACT-lite" rev-parse HEAD)"
  echo "SPT_candl_data=$(git -C "${ROOT}/external/spt_candl_data" rev-parse HEAD)"
} | tee "${PROV}/runtime-environment.txt"

python -m pip freeze | sort > "${PROV}/runtime-pip-freeze.txt"

python - <<'PY' > "${PROV}/runtime-python-packages.txt"
import importlib.metadata as m
for name in ["cobaya", "candl-like", "camb", "sacc", "numpy", "scipy", "Cython"]:
    try:
        print(f"{name}={m.version(name)}")
    except Exception as e:
        print(f"{name}=NOT_FOUND ({e})")
PY

echo "Provenance recorded."
