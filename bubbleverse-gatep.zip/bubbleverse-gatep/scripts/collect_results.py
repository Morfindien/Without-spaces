#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser(description="Collect Bubbleverse Gate-P minima.")
p.add_argument("--lcdm", type=float, required=True, help="chi2 minimum for LCDM")
p.add_argument("--oneax", type=float, required=True, help="chi2 minimum for frozen 1ax")
p.add_argument("--twoax", type=float, required=True, help="chi2 minimum for frozen 2ax")
p.add_argument("--tolerance", type=float, default=0.1, help="Numerical nesting tolerance")
p.add_argument("--out", default="results/gatep_summary.json")
args = p.parse_args()

dchi2_2v1 = args.twoax - args.oneax
daic_2v1 = dchi2_2v1 + 4.0
dchi2_1vlcdm = args.oneax - args.lcdm

nest_2v1_ok = args.twoax <= args.oneax + args.tolerance
nest_1vlcdm_ok = args.oneax <= args.lcdm + args.tolerance

if dchi2_2v1 < -4.0:
    aic_status = "2ax_AIC_preferred_over_1ax"
elif abs(dchi2_2v1 + 4.0) <= args.tolerance:
    aic_status = "AIC_neutral_within_tolerance"
else:
    aic_status = "2ax_not_AIC_justified_over_1ax"

summary = {
    "chi2_lcdm": args.lcdm,
    "chi2_1ax": args.oneax,
    "chi2_2ax": args.twoax,
    "delta_chi2_2ax_minus_1ax": dchi2_2v1,
    "delta_AIC_2ax_minus_1ax": daic_2v1,
    "delta_chi2_1ax_minus_lcdm": dchi2_1vlcdm,
    "nesting_2ax_le_1ax": nest_2v1_ok,
    "nesting_1ax_le_lcdm": nest_1vlcdm_ok,
    "aic_status": aic_status,
    "warning": (
        "Do not convert delta chi2 mechanically to sigma: "
        "f=0 is a boundary and zc is unidentified there."
    ),
}

path = Path(args.out)
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
