#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="${ROOT}/external/DR6-ACT-lite"
OUT="${ROOT}/results/validation"
mkdir -p "${OUT}"

python -m pip install -e "${SRC}"

# The upstream project uses COBAYA_PACKAGES_PATH when locating the data.
export COBAYA_PACKAGES_PATH="${COBAYA_PACKAGES_PATH:-${ROOT}/.cobaya}"
mkdir -p "${COBAYA_PACKAGES_PATH}"

cobaya-install act_dr6_cmbonly

# Official upstream tests include the reference TT/TE/EE check:
# ln L ~= -395.48 at the test cosmology.
pytest -v --pyargs act_dr6_cmbonly 2>&1 | tee "${OUT}/act_pytest.log"

echo "ACT DR6 validation: OK"
