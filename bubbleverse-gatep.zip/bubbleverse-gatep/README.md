# Bubbleverse Gate P — CASE-Q013

This repository is a validation-first execution bundle for the frozen HYP-004C Gate P test.

## What Gate P is

Gate P tests the same three models on the same primary-CMB data combination:

- ΛCDM
- frozen 1-axion EDE
- frozen 2-axion HYP-004C

Data intended for Gate P:

- ACT DR6 foreground-marginalized primary TT/TE/EE
- SPT-3G D1 primary TT/TE/EE, lite likelihood
- one explicit external tau prior from the SPT publication template
- no CMB lensing in Gate P

The decisive comparison for the second field is

    Δχ²_P = χ²_2ax,P - χ²_1ax,P
    ΔAIC_P = Δχ²_P + 4

AIC neutrality is at Δχ²_P = -4.

## Important: validation-first design

This ZIP does **not** pretend that the final Gate-P fit is ready before all frozen base-cosmology priors and the exact Cobaya→mAxiCLASS multi-field parameter mapping are recovered and tested.

The first workflow therefore only:

1. creates an Ubuntu runner,
2. builds the exact pinned mAxiCLASS commit,
3. smoke-tests the mAxiCLASS executable and Python wrapper,
4. installs the exact pinned ACT DR6 likelihood commit,
5. downloads ACT likelihood data and runs the official ACT tests,
6. installs candl-like 2.0.3,
7. installs the exact pinned SPT data commit,
8. runs the SPT supplied test suite,
9. records versions, hashes and `pip freeze`,
10. uploads logs and provenance as a GitHub Actions artifact.

Only after this is green should the final ΛCDM/1ax/2ax minimization workflow be enabled.

## Frozen source revisions

- mAxiCLASS: `marcobeIIa/mAxiCLASS`
  - commit `b5a3af9818d04d2fe696e54972545e8c6805f4ea`
- ACT DR6 lite: `ACTCollaboration/DR6-ACT-lite`
  - commit `0e0cd2c703c62a0e980470b572602233b27750e1`
- SPT candl data: `SouthPoleTelescope/spt_candl_data`
  - commit `2cec6e762a8c540484dd5acafc529f0035856350`
- candl: PyPI package `candl-like==2.0.3`

## HYP-004C frozen definition

- `N_ax = 2`
- `n = 3`
- `theta_1 = theta_2 = 2.8`
- initial theta derivatives = 0
- `log10(zc1) ∈ [3.0, 3.75]`
- `log10(zc2) ∈ [3.75, 4.5]`
- `f_ax1, f_ax2 ∈ [0, 0.3]`

Equivalent mAxiCLASS scale-factor ranges are recorded in `configs/HYP004C_LOCK.yaml`.

## How to use this ZIP

1. Create a new GitHub repository, e.g. `bubbleverse-gatep`.
2. Extract this ZIP on your phone/computer.
3. Upload **the contents of the `bubbleverse-gatep` folder** to the repository root.
4. Commit the upload.
5. Open the repository's **Actions** tab.
6. Open **Bubbleverse Gate P — Validate stack**.
7. Press **Run workflow**.

The workflow also runs automatically when the validation workflow or validation scripts are changed.

## Expected ACT validation

The pinned ACT repository's official test evaluates a reference cosmology and expects the TT/TE/EE log-likelihood to be approximately:

    ln L = -395.48

If that test fails, do not proceed to Gate P.

## SPT prior handling locked for Gate P

The SPT publication template uses:

- `clear_internal_priors: true`
- `tau ~ Normal(0.051, 0.006)`
- `Tcal ∈ [0.8, 1.2]`
- external `Tcal ~ Normal(1.0, 0.0036)`
- `Ecal ∈ [0.8, 1.2]`

The exact likelihood/prior skeleton is in `configs/gatep_likelihoods.yaml`.

## Why the final fit workflow is not auto-enabled yet

The HYP-004C EDE priors are frozen, but the final Gate-P run must also preserve the intended base-cosmology parameterisation and priors from the construction analysis. Those must not be silently replaced by ACT or SPT example priors.

Also, mAxiCLASS multi-field inputs must be passed through Cobaya in exactly the string/vector form accepted by this frozen code.

`configs/FINAL_FIT_BLOCKERS.md` records these two remaining reproducibility gates.

## Outputs

Validation artifacts are written to:

- `provenance/`
- `results/validation/`

GitHub Actions uploads them as `gatep-validation-*`.

## Safety rule

Do not interpret a failed software build as an empirical failure of HYP-004C.
A physics verdict starts only after the software/likelihood validation gate passes.
